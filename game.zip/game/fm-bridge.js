/* ============================================================================
 * fm-bridge.js —  Construct 3 游戏  ⇄  FileMaker 桥接层   v1.0
 * ----------------------------------------------------------------------------
 * 由 index.html 在 C3 运行时之前以普通 <script> 加载（不是 module）。
 *
 * FileMaker → 游戏（三条入口，优先级从高到低）
 *   1) Perform JavaScript in Web Viewer  →  receiveFromFileMaker(json字符串)
 *      例：Function Name = receiveFromFileMaker ; Parameters = JSONSetElement(...)
 *   2) 网页地址带参数： index.html?ctx=<Base64(JSON)>   或  ?ctx={"a":1}
 *   3) GET /api/context —— 服务端读取 server/context.json（由 FM 导出字段内容写入）
 *
 * 游戏 → FileMaker（两条出口）
 *   1) FileMaker.PerformScript("c3_OnGameEvent", json)   ← 默认，需在 Web Viewer
 *      勾选「允许 JavaScript 执行 FileMaker 脚本」
 *   2) POST /api/result   ← 兜底；FileMaker 用「Insert from URL」读
 *      http://127.0.0.1:8787/api/latest_result
 *
 * 给 C3 事件表用的 API（在「Run JavaScript」动作里直接写）：
 *   const ctx = window.FMGame.getContext();      // 拿到 FileMaker 传进来的数据
 *   window.FMGame.send('score', { score: 120 }); // 把数据回传给 FileMaker
 * ========================================================================== */
(function () {
    'use strict';

    var APP = 'c3';
    var params = new URLSearchParams(window.location.search);
    var outMode = (params.get('out') || 'auto').toLowerCase(); // auto | script | http
    var token = params.get('token') || '';

    var context = null;      // 当前上下文数据
    var listeners = [];      // 消息订阅者
    var ready = false;
    var started = false;

    function log() {
        try { console.log.apply(console, ['[FMGame]'].concat([].slice.call(arguments))); } catch (e) { }
    }

    /* ---------------------------------------------------------------- 工具 */

    function b64ToUtf8(s) {
        s = String(s);
        s = s.replace(/ /g, '+');                 // Base64 里的 '+' 在 URL 查询串中会被解析成空格
        s = s.replace(/[^A-Za-z0-9+/=_-]/g, '');  // 清掉 RFC2045 的换行、制表符等
        s = s.replace(/-/g, '+').replace(/_/g, '/');
        while (s.length % 4) { s += '='; }
        var bin = atob(s);
        var bytes = new Uint8Array(bin.length);
        for (var i = 0; i < bin.length; i++) { bytes[i] = bin.charCodeAt(i); }
        return new TextDecoder('utf-8').decode(bytes);
    }

    function parseContext(raw) {
        if (raw === null || raw === undefined || raw === '') { return null; }
        raw = String(raw).trim();
        if (raw.charAt(0) === '{' || raw.charAt(0) === '[') {   // 已经是 JSON 文本
            try { return JSON.parse(raw); } catch (e) { log('ctx 不是合法 JSON', e); return null; }
        }
        try { return JSON.parse(b64ToUtf8(raw)); }               // Base64（推荐）
        catch (e) { log('ctx Base64 解析失败', e); return null; }
    }

    function toast(text) {
        try {
            if (!document.body) { return; }
            var el = document.getElementById('fmg-toast');
            if (!el) {
                el = document.createElement('div');
                el.id = 'fmg-toast';
                el.style.cssText =
                    'position:fixed;left:50%;bottom:20px;transform:translateX(-50%);z-index:2147483647;' +
                    'max-width:80%;padding:10px 18px;border-radius:10px;background:rgba(18,20,26,.92);' +
                    'color:#fff;font:14px/1.6 "Microsoft YaHei",system-ui,sans-serif;pointer-events:none;' +
                    'box-shadow:0 6px 22px rgba(0,0,0,.4);opacity:0;transition:opacity .25s;white-space:pre-wrap;';
                document.body.appendChild(el);
            }
            el.textContent = String(text);
            el.style.opacity = '1';
            clearTimeout(toast._t);
            toast._t = setTimeout(function () { el.style.opacity = '0'; }, 2800);
        } catch (e) { }
    }

    /* ------------------------------------------------------------ 事件分发 */

    function emit(msg) {
        for (var i = 0; i < listeners.length; i++) {
            try { listeners[i](msg); } catch (e) { log('消息处理函数抛错', e); }
        }
    }

    function applyContext(obj) {
        context = (obj === null || obj === undefined) ? null : obj;
        emit({ type: 'context', context: context });
    }

    /* --------------------------------------------------- 游戏 → FileMaker */

    function hasScriptChannel() {
        return !!(window.FileMaker && typeof window.FileMaker.PerformScript === 'function');
    }

    function postResult(json) {
        try {
            if (navigator.sendBeacon) {
                var blob = new Blob([json], { type: 'application/json' });
                if (navigator.sendBeacon('/api/result', blob)) { return true; }
            }
        } catch (e) { }
        try {
            fetch('/api/result', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: json,
                keepalive: true
            }).catch(function (e) { log('POST /api/result 失败', e); });
            return true;
        } catch (e) { log('POST /api/result 异常', e); return false; }
    }

    function send(type, data) {
        var payload = {
            app: APP,
            type: String(type),
            data: (data === undefined ? null : data),
            token: token,
            ts: Date.now(),
            url: location.href
        };
        var json = JSON.stringify(payload);

        var wantScript = (outMode !== 'http');
        if (wantScript && hasScriptChannel()) {
            try {
                window.FileMaker.PerformScript('c3_OnGameEvent', json);
                return json;
            } catch (e) {
                log('FileMaker.PerformScript 失败，改用 HTTP', e);
            }
        }
        if (outMode !== 'script' || !hasScriptChannel()) { postResult(json); }
        return json;
    }

    /* --------------------------------------------------- FileMaker → 游戏 */

    function receive(raw) {
        var obj;
        if (typeof raw !== 'string') { obj = raw; }
        else {
            var s = raw.trim();
            if (s.charAt(0) === '{' || s.charAt(0) === '[') {
                try { obj = JSON.parse(s); } catch (e) { obj = { type: 'raw', data: raw }; }
            } else {
                obj = parseContext(s) || { type: 'raw', data: raw };
            }
        }
        if (obj && typeof obj === 'object' && obj.type) {
            if (obj.type === 'context' || obj.type === 'setContext') {
                applyContext(obj.data !== undefined ? obj.data : obj.context);
            } else {
                emit(obj);
            }
        } else {
            applyContext(obj);   // 直接推来一个数据对象，就当成上下文
        }
        return true;
    }

    function fetchContext() {
        return fetch('/api/context', { cache: 'no-store' })
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (j) {
                if (j && Object.keys(j).length) { applyContext(j); }
                return j;
            })
            .catch(function (e) { log('GET /api/context 失败', e); return null; });
    }

    /* -------------------------------------------------------------- 启动 */

    function boot() {
        if (started) { return; }
        started = true;

        var ctx = parseContext(params.get('ctx'));
        if (ctx) { applyContext(ctx); }

        // 如果地址里没有 ctx，就试着向本地服务要一份
        if (!ctx && params.get('ctxfile') === '1') { fetchContext(); }

        ready = true;
        emit({ type: 'ready' });
        send('ready', { href: location.href, ua: navigator.userAgent });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    /* ------------------------------------------------------- 拦截 alert() */
    // 游戏里现有的 alert() 在 WebView2 里会弹出原生对话框，很碍事。
    // 这里改成页面内浮层，并顺手把它作为一个事件回传给 FileMaker。
    window.alert = function (message) {
        toast(message);
        send('alert', { message: String(message) });
    };

    /* ----------------------------------------------------------- 对外接口 */

    window.FMGame = {
        version: '1.0',
        getContext: function () { return context; },
        get: function (key) {
            if (key === undefined) { return context; }
            return context ? context[key] : undefined;
        },
        receive: receive,
        send: send,
        on: function (fn) {
            if (typeof fn !== 'function') { return function () { }; }
            listeners.push(fn);
            return function () {
                var i = listeners.indexOf(fn);
                if (i >= 0) { listeners.splice(i, 1); }
            };
        },
        fetchContext: fetchContext,
        isReady: function () { return ready; },
        toast: toast
    };

    // FileMaker 里「Perform JavaScript in Web Viewer」使用的全局函数名
    window.receiveFromFileMaker = receive;

    log('桥接层已加载', { out: outMode, hasCtxParam: params.has('ctx') });
})();
