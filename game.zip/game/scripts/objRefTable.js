const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Button,
		C3.Plugins.Sprite,
		C3.Behaviors.solid,
		C3.Behaviors.Platform,
		C3.Plugins.TiledBg,
		C3.Plugins.Text,
		C3.Plugins.TextBox,
		C3.Plugins.Keyboard,
		C3.Plugins.Button.Cnds.OnClicked,
		C3.JavaScriptInEvents.EventSheet1_Event1_Act1,
		C3.Plugins.Sprite.Cnds.OnCollision,
		C3.Plugins.System.Acts.GoToLayout,
		C3.Plugins.Text.Acts.SetVisible,
		C3.Plugins.TextBox.Acts.SetVisible,
		C3.JavaScriptInEvents.EventSheet1_Event5_Act1
	];
};
self.C3_JsPropNameTable = [
	{Button: 0},
	{实体: 0},
	{平台: 0},
	{主角: 0},
	{传送点: 0},
	{平铺图: 0},
	{场景全图: 0},
	{精灵: 0},
	{传送点2: 0},
	{精灵2: 0},
	{按钮: 0},
	{文本: 0},
	{输入框: 0},
	{键盘: 0},
	{提交: 0}
];

self.InstanceType = {
	Button: class extends self.IButtonInstance {},
	平台: class extends self.ISpriteInstance {},
	主角: class extends self.ISpriteInstance {},
	传送点: class extends self.ISpriteInstance {},
	平铺图: class extends self.ITiledBackgroundInstance {},
	场景全图: class extends self.ISpriteInstance {},
	精灵: class extends self.ISpriteInstance {},
	传送点2: class extends self.ISpriteInstance {},
	精灵2: class extends self.ISpriteInstance {},
	按钮: class extends self.IButtonInstance {},
	文本: class extends self.ITextInstance {},
	输入框: class extends self.ITextInputInstance {},
	键盘: class extends self.IInstance {},
	提交: class extends self.IButtonInstance {}
}