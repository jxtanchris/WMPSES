

const scriptsInEvents = {

	async EventSheet1_Event1_Act1(runtime, localVars)
	{
		alert("Hello world!");
	},

	async EventSheet1_Event5_Act1(runtime, localVars)
	{
		const box = runtime.objects["输入框"].getFirstInstance();
		window.FMGame.send("submit", { name: box ? box.text : "" });
	}
};

globalThis.C3.JavaScriptInEvents = scriptsInEvents;
